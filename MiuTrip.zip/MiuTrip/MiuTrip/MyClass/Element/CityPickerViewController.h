//
//  CityPickerViewController.h
//  MiuTrip
//
//  Created by apple on 13-11-30.
//  Copyright (c) 2013年 michael. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CityPickerViewController : UIViewController

@end
