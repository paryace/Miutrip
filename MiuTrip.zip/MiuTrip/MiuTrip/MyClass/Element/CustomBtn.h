//
//  CustomBtn.h
//  MiuTrip
//
//  Created by SuperAdmin on 13-11-18.
//  Copyright (c) 2013年 michael. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CustomBtn : UIButton

@property (strong, nonatomic) NSIndexPath               *indexPath;

@end
