//
//  DBAirLine.h
//  MiuTrip
//
//  Created by Samrt_baot on 14-1-16.
//  Copyright (c) 2014年 michael. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface DBAirLine : NSObject

@property (strong, nonatomic) NSString      *airLine;
@property (strong, nonatomic) NSString      *name;
@property (strong, nonatomic) NSString      *short_name;

@end
