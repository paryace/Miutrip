//
//  HotCityData.m
//  MiuTrip
//
//  Created by GX on 14-1-22.
//  Copyright (c) 2014年 michael. All rights reserved.
//

#import "HotCityData.h"

@implementation HotCityData

@end
