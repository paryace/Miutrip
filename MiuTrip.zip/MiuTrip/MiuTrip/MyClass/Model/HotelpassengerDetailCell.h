//
//  HotelpassengerDetailCell.h
//  MiuTrip
//
//  Created by pingguo on 14-1-16.
//  Copyright (c) 2014年 michael. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HotelpassengerDetailCell : UITableViewCell

@property (strong, nonatomic) UILabel *userName;
@property (strong, nonatomic) UIButton *itemBtn;

@end
