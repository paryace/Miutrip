//
//  HotelCitesResponse.m
//  MiuTrip
//
//  Created by stevencheng on 13-11-29.
//  Copyright (c) 2013年 michael. All rights reserved.
//

#import "HotelCitesResponse.h"

@implementation HotelCitesResponse



@end
