//
//  CorpServerCardDTO.m
//  MiuTrip
//
//  Created by apple on 13-11-28.
//  Copyright (c) 2013年 michael. All rights reserved.
//

#import "CorpServerCardDTO.h"

@implementation CorpServerCardDTO

@end
