//
//  GetBizSummary_AtMiutripRequest.m
//  MiuTrip
//
//  Created by GX on 14-2-12.
//  Copyright (c) 2014年 michael. All rights reserved.
//

#import "GetBizSummary_AtMiutripRequest.h"

@implementation GetBizSummary_AtMiutripRequest

@end
