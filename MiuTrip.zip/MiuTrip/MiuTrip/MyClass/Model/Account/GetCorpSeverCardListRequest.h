//
//  GetCorpSeverCardList.h
//  MiuTrip
//
//  Created by Y on 13-12-2.
//  Copyright (c) 2013年 michael. All rights reserved.
//

#import "BaseRequestModel.h"
#import "BaseResponseModel.h"
///////////////GetSeverCaardRequest//////////////////////////////////////


@interface GetCorpSeverCardListRequest : BaseRequestModel

@property (strong, nonatomic) NSString      *CorpUID; 

@end

