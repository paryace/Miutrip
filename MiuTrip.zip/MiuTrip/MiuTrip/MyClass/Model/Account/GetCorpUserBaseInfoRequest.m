//
//  GetcorpUserBaseInfo.m
//  MiuTrip
//
//  Created by Y on 13-12-2.
//  Copyright (c) 2013年 michael. All rights reserved.
//

#import "GetCorpUserBaseInfoRequest.h"

@implementation GetCorpUserBaseInfoRequest

@end
