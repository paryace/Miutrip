//
//  BindingUserByUMSRequest.m
//  MiuTrip
//
//  Created by apple on 14-3-7.
//  Copyright (c) 2014年 michael. All rights reserved.
//

#import "BindingUserByUMSRequest.h"

@implementation BindingUserByUMSRequest

@end
