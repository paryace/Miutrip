//
//  GetTravelLifeInfoResponse.m
//  MiuTrip
//
//  Created by Y on 13-12-4.
//  Copyright (c) 2013年 michael. All rights reserved.
//

#import "GetTravelLifeInfoResponse.h"

@implementation GetTravelLifeInfoResponse

@end
