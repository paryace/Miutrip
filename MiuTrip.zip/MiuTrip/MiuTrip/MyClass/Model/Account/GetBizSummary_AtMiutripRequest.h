//
//  GetBizSummary_AtMiutripRequest.h
//  MiuTrip
//
//  Created by GX on 14-2-12.
//  Copyright (c) 2014年 michael. All rights reserved.
//

#import "BaseRequestModel.h"

@interface GetBizSummary_AtMiutripRequest : BaseRequestModel

@end
