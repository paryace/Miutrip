//
//  ActiveGiftCardUserRequest.m
//  MiuTrip
//
//  Created by apple on 14-3-7.
//  Copyright (c) 2014年 michael. All rights reserved.
//

#import "ActiveGiftCardUserRequest.h"

@implementation ActiveGiftCardUserRequest

@end
