//
//  ForgetPasswordResponse.h
//  MiuTrip
//
//  Created by MB Pro on 2/19/14.
//  Copyright (c) 2014 michael. All rights reserved.
//

#import "BaseResponseModel.h"

@interface ForgetPasswordResponse : BaseResponseModel

@end
