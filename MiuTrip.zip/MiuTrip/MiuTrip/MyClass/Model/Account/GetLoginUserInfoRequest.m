


//
//  GetLoginUserInforequest.m
//  MiuTrip
//
//  Created by Y on 13-12-2.
//  Copyright (c) 2013年 michael. All rights reserved.
//

#import "GetLoginUserInfoRequest.h"

@implementation GetLoginUserInfoRequest

- (BaseRequestModel *)initWidthBusinessType:(BusinessType)bussinessType methodName:(NSString *)methodName
{
    if (self = [super initWidthBusinessType:bussinessType methodName:methodName]) {
//        _uid = @"15000609705";
    }
    return self;
}

@end
