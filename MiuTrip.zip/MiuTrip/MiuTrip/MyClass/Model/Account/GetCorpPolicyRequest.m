
//
//  GetCorpPolicyRequest.m
//  MiuTrip
//
//  Created by Y on 13-12-2.
//  Copyright (c) 2013年 michael. All rights reserved.
//

#import "GetCorpPolicyRequest.h"

@implementation GetCorpPolicyRequest

@end
