//
//  GetBizSummary_AtMiutripResponse.m
//  MiuTrip
//
//  Created by GX on 14-2-12.
//  Copyright (c) 2014年 michael. All rights reserved.
//

#import "GetBizSummary_AtMiutripResponse.h"

@implementation GetBizSummary_AtMiutripResponse

@end
