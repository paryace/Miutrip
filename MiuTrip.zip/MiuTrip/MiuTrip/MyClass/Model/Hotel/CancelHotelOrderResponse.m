//
//  CancelHotelResponse.m
//  MiuTrip
//
//  Created by Y on 14-1-21.
//  Copyright (c) 2014年 michael. All rights reserved.
//

#import "CancelHotelOrderResponse.h"

@implementation CancelHotelOrderResponse

@end
