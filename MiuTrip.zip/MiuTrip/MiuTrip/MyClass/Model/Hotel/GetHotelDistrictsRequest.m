//
//  GetHotelDistrictsRequest.m
//  MiuTrip
//
//  Created by stevencheng on 13-12-22.
//  Copyright (c) 2013年 michael. All rights reserved.
//

#import "GetHotelDistrictsRequest.h"

@implementation GetHotelDistrictsRequest

@end
