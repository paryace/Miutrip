//
//  CancelHotelResponse.h
//  MiuTrip
//
//  Created by Y on 14-1-2.
//  Copyright (c) 2014年 michael. All rights reserved.
//

#import "BaseResponseModel.h"

@interface CancelHotelOrderResponse: BaseResponseModel

@property (strong , nonatomic) NSString  *OrderID;

@end
