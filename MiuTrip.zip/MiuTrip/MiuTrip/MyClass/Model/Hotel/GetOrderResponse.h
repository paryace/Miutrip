//
//  GetOrderResponse.h
//  MiuTrip
//
//  Created by pingguo on 13-12-2.
//  Copyright (c) 2013年 michael. All rights reserved.
//

#import "BaseResponseModel.h"

@interface GetOrderResponse : BaseResponseModel

//@property(strong,nonatomic) NSNumber *TotalPage;
@property(strong,nonatomic) NSArray *Data;
//@property(strong,nonatomic) NSString *OrderID;
//@property(strong,nonatomic) NSNumber *Status;
//@property(strong,nonatomic) NSNumber *OrderType;
//@property(strong,nonatomic) NSNumber *HotelID;
//@property(strong,nonatomic) NSString *HotelName;
//@property(strong,nonatomic) NSString *RoomTypeName;
//@property(strong,nonatomic) NSNumber *RoomNumber;
//@property(strong,nonatomic) NSNumber *Amount;
//@property(strong,nonatomic) NSString *ComeDate;
//@property(strong,nonatomic) NSString *LeaveDate;
//@property(strong,nonatomic) NSString *ContactName;
//@property(strong,nonatomic) NSString *ContactMobile;
//@property(strong,nonatomic) NSNumber *CanCancel;
//@property(strong,nonatomic) NSNumber *CanPay;
//@property(strong,nonatomic) NSString *PaySerialId;
//@property(strong,nonatomic) NSDictionary *Guests;
//@property(strong,nonatomic) NSString *UserName;
//@property(strong,nonatomic) NSString *CostCenter;
//@property(strong, nonatomic)NSNumber *ShareAmount;
@end
