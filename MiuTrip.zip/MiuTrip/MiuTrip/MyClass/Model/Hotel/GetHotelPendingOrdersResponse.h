//
//  GetHotelPendingOrdersResponse.h
//  MiuTrip
//
//  Created by Y on 14-2-25.
//  Copyright (c) 2014年 michael. All rights reserved.
//

#import "BaseResponseModel.h"

@interface GetHotelPendingOrdersResponse : BaseResponseModel

@property(strong,nonatomic) NSArray *Data;

@end
