//
//  GetHotelPendingOrdersResponse.m
//  MiuTrip
//
//  Created by Y on 14-2-25.
//  Copyright (c) 2014年 michael. All rights reserved.
//

#import "GetHotelPendingOrdersResponse.h"

@implementation GetHotelPendingOrdersResponse

@end
