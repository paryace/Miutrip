//
//  GetHotelPendingOrdersRequest.h
//  MiuTrip
//
//  Created by Y on 14-2-25.
//  Copyright (c) 2014年 michael. All rights reserved.
//

#import "BaseRequestModel.h"

@interface GetHotelPendingOrdersRequest : BaseRequestModel

@property(strong, nonatomic) NSNumber *NotTravel;

@end
