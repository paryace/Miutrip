//
//  GetHotelDistrictsResponse.h
//  MiuTrip
//
//  Created by stevencheng on 13-12-22.
//  Copyright (c) 2013年 michael. All rights reserved.
//

#import "BaseResponseModel.h"

@interface GetHotelDistrictsResponse : BaseResponseModel


@property (nonatomic,strong) NSArray *Data;

@end
