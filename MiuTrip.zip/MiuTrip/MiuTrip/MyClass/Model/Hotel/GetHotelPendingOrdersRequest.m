//
//  GetHotelPendingOrdersRequest.m
//  MiuTrip
//
//  Created by Y on 14-2-25.
//  Copyright (c) 2014年 michael. All rights reserved.
//

#import "GetHotelPendingOrdersRequest.h"

@implementation GetHotelPendingOrdersRequest

@end
