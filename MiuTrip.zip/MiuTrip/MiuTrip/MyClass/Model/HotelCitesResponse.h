//
//  HotelCitesResponse.h
//  MiuTrip
//
//  Created by stevencheng on 13-11-29.
//  Copyright (c) 2013年 michael. All rights reserved.
//

#import "BaseResponseModel.h"

@interface HotelCitesResponse : BaseResponseModel


@property (nonatomic,strong) NSDictionary *Data;

@end
