//
//  TravelLifeInfo.m
//  MiuTrip
//
//  Created by apple on 13-11-28.
//  Copyright (c) 2013年 michael. All rights reserved.
//

#import "TravelLifeInfo.h"
#import "Utils.h"
#import "BaseResponseModel.h"
@implementation TravelLifeInfo

- (id)init{
    self = [super init];
    if (self) {
        
    }
    return self;
}
//- (id)initWithData:(NSDictionary*)data
//{
//    if (self = [super init]) {
//        _Fli_City = [data objectForKey:@"Fli_City"];
//        _Fli_FliCount = [data objectForKey:@"Fli_FliCount"];
//        _Fli_FliMostStutes = [data objectForKey:@"Fli_FliMostStutes"];
//        _Fli_FliPrice = [data objectForKey:@"Fli_FliPrice"];
//        _Fli_FliTotalPrice = [data objectForKey:@"Fli_FliTotalPrice"];
//        _Fli_FlightKM = [data objectForKey:@"Fli_FlightKM"];
//        _Fli_HotCityCount = [data objectForKey:@"Fli_HotCityCount"];
//        _Fli_HotCityName = [data objectForKey:@"Fli_HotCityName"];
//        _Fli_province = [data objectForKey:@"Fli_province"];
//        _Hot_HotDayCount = [data objectForKey:@"Hot_HotDayCount"];
//        _Hot_HotMostCount = [data objectForKey:@"Hot_HotMostCount"];
//        _Hot_HotName = [data objectForKey:@"Hot_HotName"];
//        _Hot_HotPrice = [data objectForKey:@"Hot_HotPrice"];
//        _Hot_HotStars = [data objectForKey:@"Hot_HotStars"];
//        _Hot_HotTotalCount = [data objectForKey:@"Hot_HotTotalCount"];
//        _Hot_HotTotalPrice = [data objectForKey:@"Hot_HotTotalPrice"];
//        _Hot_RC_Count = [data objectForKey:@"Hot_RC_Count"];
//        _TimeSpan = [data objectForKey:@"TimeSpan"];
//        _UID = [data objectForKey:@"UID"];
//    }
//    return self;
//}

@end
