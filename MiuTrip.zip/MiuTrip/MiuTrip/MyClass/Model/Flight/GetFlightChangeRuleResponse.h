//
//  GetFlightChangeRuleResponse.h
//  MiuTrip
//
//  Created by pingguo on 13-12-4.
//  Copyright (c) 2013年 michael. All rights reserved.
//

#import "BaseResponseModel.h"
#import "OnLineAllClass.h"

@interface GetFlightChangeRuleResponse : BaseResponseModel


@property(strong, nonatomic) Rule   *rule;

@end

