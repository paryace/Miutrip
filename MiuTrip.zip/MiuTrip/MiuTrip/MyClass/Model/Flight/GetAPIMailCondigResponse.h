//
//  GetAPIMailCondigResponse.h
//  MiuTrip
//
//  Created by GX on 14-2-18.
//  Copyright (c) 2014年 michael. All rights reserved.
//

#import "BaseResponseModel.h"

@interface GetAPIMailCondigResponse : BaseResponseModel
@property (strong,nonatomic) NSArray *mList;
@end
