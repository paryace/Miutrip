//
//  GetFlightorderListResponse.m
//  MiuTrip
//
//  Created by pingguo on 13-12-3.
//  Copyright (c) 2013年 michael. All rights reserved.
//

#import "GetFlightOrderListResponse.h"

@implementation GetFlightOrderListResponse

@end
