//
//  GetAPIMailCondigRequest.h
//  MiuTrip
//
//  Created by GX on 14-2-18.
//  Copyright (c) 2014年 michael. All rights reserved.
//

#import "BaseRequestModel.h"

@interface GetAPIMailCondigRequest : BaseRequestModel
@property(strong, nonatomic)  NSNumber *oTAType;
@end
