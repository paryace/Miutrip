//
//  GetMailConfigRequest.h
//  MiuTrip
//
//  Created by pingguo on 13-12-4.
//  Copyright (c) 2013年 michael. All rights reserved.
//

#import "BaseRequestModel.h"
#import "URLHelper.h"
#import "GetMailConfigResponse.h"

@interface GetMailConfigRequest : BaseRequestModel

@property(strong, nonatomic) NSNumber *oTAType;

@end
