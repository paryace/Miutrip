//
//  Nation.h
//  MiuTrip
//
//  Created by GX on 14-1-12.
//  Copyright (c) 2014年 michael. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Nation : NSObject

@property (strong, nonatomic) NSString      *name;  //英文名
@property (strong, nonatomic) NSString      *china_name;    //中文名
@property (strong, nonatomic) NSString      *abb_name;

@end
