//
//  SettingViewController.h
//  MiuTrip
//
//  Created by SuperAdmin on 13-11-18.
//  Copyright (c) 2013年 michael. All rights reserved.
//

#import "BaseUIViewController.h"

@interface SettingViewController : BaseUIViewController

@end
