//
//  AppDelegate.h
//  MiuTrip
//
//  Created by SuperAdmin on 11/13/13.
//  Copyright (c) 2013 michael. All rights reserved.
//

#import <UIKit/UIKit.h>

@class BaseUIViewController;

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;
@property (strong, nonatomic) BaseUIViewController *viewController;
@property (assign, nonatomic) BOOL isForSelf;


@end
