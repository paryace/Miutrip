//
//  GetDistrictsRequest.m
//  MiuTrip
//
//  Created by Y on 13-12-3.
//  Copyright (c) 2013年 michael. All rights reserved.
//

#import "GetDistrictsRequest.h"

@implementation GetDistrictsRequest

@end
