//
//  SaveSMSRequest.h
//  MiuTrip
//
//  Created by Y on 13-12-3.
//  Copyright (c) 2013年 michael. All rights reserved.
//

#import "BaseRequestModel.h"
////////////////////////////////////

@interface SaveSMSRequest : BaseRequestModel


@property (nonatomic , strong) NSNumber  *SMSID;
@property (nonatomic , strong) NSNumber  *BussinessType;
@property (nonatomic , strong) NSString  *OrderID;
@property (nonatomic , strong) NSString  *Mobile;
@property (nonatomic , strong) NSString  *SmsContent;
@property (nonatomic , strong) NSString  *AddCode;
@property (nonatomic , strong) NSNumber  *Priority;
@property (nonatomic , strong) NSData  *SendTime;
@property (nonatomic , strong) NSData  *ScheduleTime;
@property (nonatomic , strong) NSData  *Deadline;
@property (nonatomic , strong) NSString  *Satatus;
@property (nonatomic , strong) NSNumber  *TotalCount;
@property (nonatomic , strong) NSNumber  *Retry;
@property (nonatomic , strong) NSString  *Creater;
@property (nonatomic , strong) NSData  *CreateTime;
@property (nonatomic , strong) NSString  *Channel;
@property (nonatomic , strong) NSData  *OperatreTime;
@property (nonatomic , strong) NSString  *ErrorCode;

@end
