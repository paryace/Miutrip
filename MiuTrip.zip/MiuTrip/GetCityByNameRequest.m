//
//  GetCityByNameRequest.m
//  MiuTrip
//
//  Created by Y on 13-12-3.
//  Copyright (c) 2013年 michael. All rights reserved.
//

#import "GetCityByNameRequest.h"

@implementation GetCityByNameRequest

@end
