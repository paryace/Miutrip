//
//  GetDistrictsRequest.h
//  MiuTrip
//
//  Created by Y on 13-12-3.
//  Copyright (c) 2013年 michael. All rights reserved.
//

#import "BaseRequestModel.h"
#import "BaseResponseModel.h"
//////////////////////////////////////////////////////////////

@interface GetDistrictsRequest : BaseRequestModel

@property (nonatomic , strong) NSNumber  *CityID;

@end


@interface GetDistrictsResponse : BaseResponseModel

@property (nonatomic , strong) NSDictionary  *Data;

@end


@interface DistrictMibileResponse : BaseResponseModel

@property (nonatomic , strong) NSNumber  *ID;
@property (nonatomic , strong) NSString  *DistrictName;

@end